import BG_IMG from "./wedding_bg.jpg";
import COUPLE from "./couple.jpg";

export { BG_IMG, COUPLE};
