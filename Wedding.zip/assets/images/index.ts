import BG_IMG from "./wedding_bg.jpg";

export { BG_IMG};
