"use client";
import { BG_IMG } from "@/assets/images";
import Image from "next/image";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import AOS from "aos";
// import "aos/dist/aos.css";
import UploadPage from "@/components/upload-form";
import { useState } from "react";

// AOS.init();

export default function Home() {
  const [uploadPageActive, setUploadPageActive] = useState(false);

  const toggleUploadPage = () => {
    setUploadPageActive((prev) => !prev);
  };

  return (
    <>
      {uploadPageActive ? (
        <UploadPage setUploadPageActive={toggleUploadPage} />
      ) : (
        <main className="relative flex h-screen flex-col items-center justify-center p-5">
          <div className="absolute top-0 left-0 w-full h-full -z-10">
            <Image
              alt="wedding"
              src={BG_IMG}
              layout="fill"
              objectFit="cover"
              quality={100}
              className="brightness-75"
            />
          </div>

          <div className="flex flex-col md:gap-8 gap-2 items-center">
            <h1
              className="md:text-6xl text-4xl italic font-[Love] text-white"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              Oluwaseye
            </h1>
            <h1
              className="text-white text-4xl md:text-6xl italic font-[Love]"
              data-aos="fade-up"
              data-aos-delay="500"
              data-aos-duration="1000"
            >
              &
            </h1>
            <h1
              className="text-white text-4xl md:text-6xl italic font-[Love]"
              data-aos="fade-up"
              data-aos-delay="800"
              data-aos-duration="1000"
            >
              Oluwatimileyin
            </h1>
          </div>
          <p
            className="text-xl font-[Love] text-center text-white mt-8"
            data-aos="fade-up"
            data-aos-delay="1100"
            data-aos-duration="1000"
          >
            Join us in celebrating our special day. Share your moments with us!
          </p>
          <div
            className="text-lg cursor-pointer flex items-center gap-3 mt-5 border-white text-center text-white italic font-[Love]"
            data-aos="fade-up"
            data-aos-delay="1200"
            data-aos-duration="1000"
            onClick={toggleUploadPage}
          >
            <p>Share Your Moment</p>
            <FontAwesomeIcon icon={faArrowRight} className="text-2xl mt-1" />
          </div>
          <div className="absolute top-0 left-0 min-w-full min-h-full -z-10 bg-black opacity-65"></div>
        </main>
      )}
    </>
  );
}
